/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

package com.enterprise.ems.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "leave_balances")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LeaveBalance {
    @Id
    private String id;

    @Column(name = "employee_id", nullable = false, unique = true)
    private String employeeId;

    @Builder.Default
    private Integer annual = 25;

    @Builder.Default
    private Integer sick = 15;

    @Builder.Default
    private Integer casual = 10;

    @Builder.Default
    private Integer maternity = 90;

    @Builder.Default
    private Integer unpaid = 10;
}
