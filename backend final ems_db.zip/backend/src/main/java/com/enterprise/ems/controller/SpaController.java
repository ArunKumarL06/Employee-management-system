/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

package com.enterprise.ems.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class SpaController {
    
    @RequestMapping(value = {
        "/",
        "/dashboard",
        "/employees",
        "/departments",
        "/attendance",
        "/leaves",
        "/payroll",
        "/logs",
        "/settings"
    })
    public String forwardToSpa() {
        return "forward:/index.html";
    }
}
