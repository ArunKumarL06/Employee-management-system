/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

package com.enterprise.ems.controller;

import com.enterprise.ems.entity.SystemLog;
import com.enterprise.ems.repository.SystemLogRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/v1/logs")
public class SystemLogController {

    private final SystemLogRepository systemLogRepository;

    public SystemLogController(SystemLogRepository systemLogRepository) {
        this.systemLogRepository = systemLogRepository;
    }

    @GetMapping
    public ResponseEntity<List<SystemLog>> getLogs() {
        return ResponseEntity.ok(systemLogRepository.findAllByOrderByTimestampDesc());
    }

    @PostMapping
    public ResponseEntity<SystemLog> logAction(@RequestBody SystemLog log) {
        log.setId("log-" + UUID.randomUUID().toString().substring(0, 8));
        if (log.getTimestamp() == null) {
            log.setTimestamp(LocalDateTime.now());
        }
        SystemLog saved = systemLogRepository.save(log);
        return ResponseEntity.ok(saved);
    }

    @DeleteMapping
    public ResponseEntity<?> clearLogs() {
        systemLogRepository.deleteAll();
        return ResponseEntity.ok("Successfully cleared all system audit trail registers.");
    }
}
