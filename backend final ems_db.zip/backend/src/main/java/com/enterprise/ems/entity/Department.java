/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

package com.enterprise.ems.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "departments")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Department {
    @Id
    private String id;

    @Column(nullable = false, unique = true)
    private String name;

    @Column(nullable = false, unique = true, length = 15)
    private String code;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Column(name = "manager_id")
    private String managerId;
}
