/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

package com.enterprise.ems.controller;

import com.enterprise.ems.entity.LeaveRequest;
import com.enterprise.ems.entity.LeaveBalance;
import com.enterprise.ems.repository.LeaveRequestRepository;
import com.enterprise.ems.repository.LeaveBalanceRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.UUID;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/v1/leaves")
public class LeaveController {

    private final LeaveRequestRepository leaveRequestRepository;
    private final LeaveBalanceRepository leaveBalanceRepository;

    public LeaveController(LeaveRequestRepository leaveRequestRepository, LeaveBalanceRepository leaveBalanceRepository) {
        this.leaveRequestRepository = leaveRequestRepository;
        this.leaveBalanceRepository = leaveBalanceRepository;
    }

    @GetMapping
    public ResponseEntity<List<LeaveRequest>> getLeaves(@RequestParam(required = false) String employeeId) {
        if (employeeId != null) {
            return ResponseEntity.ok(leaveRequestRepository.findAllByEmployeeId(employeeId));
        }
        return ResponseEntity.ok(leaveRequestRepository.findAll());
    }

    @GetMapping("/balances")
    public ResponseEntity<List<LeaveBalance>> getAllBalances() {
        return ResponseEntity.ok(leaveBalanceRepository.findAll());
    }

    @GetMapping("/balances/{employeeId}")
    public ResponseEntity<LeaveBalance> getBalanceByEmployeeId(@PathVariable String employeeId) {
        return leaveBalanceRepository.findByEmployeeId(employeeId)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/apply")
    public ResponseEntity<?> applyLeave(@Valid @RequestBody LeaveRequest request) {
        // Calculate duration days
        long gapDays = ChronoUnit.DAYS.between(request.getStartDate(), request.getEndDate()) + 1;

        // Fetch leave balances
        LeaveBalance bal = leaveBalanceRepository.findByEmployeeId(request.getEmployeeId())
                .orElse(null);

        if (bal != null && !request.getLeaveType().equalsIgnoreCase("UNPAID")) {
            int currentBal = getCategoryBalance(bal, request.getLeaveType());
            if (currentBal < gapDays) {
                return ResponseEntity.badRequest().body("Error: Insufficient leave balance! You have " + currentBal + " days, but requested " + gapDays);
            }
        }

        request.setId("leave-" + UUID.randomUUID().toString().substring(0, 8));
        request.setStatus("PENDING");
        request.setAppliedDate(LocalDate.now());

        LeaveRequest saved = leaveRequestRepository.save(request);
        return ResponseEntity.ok(saved);
    }

    @PutMapping("/approve/{id}")
    public ResponseEntity<?> approveLeave(@PathVariable String id, @RequestParam String approver, @RequestParam(required = false) String remarks) {
        LeaveRequest req = leaveRequestRepository.findById(id).orElse(null);
        if (req == null) {
            return ResponseEntity.notFound().build();
        }

        if (!req.getStatus().equals("PENDING")) {
            return ResponseEntity.badRequest().body("Error: This request was already finalized!");
        }

        long gapDays = ChronoUnit.DAYS.between(req.getStartDate(), req.getEndDate()) + 1;

        // Deduct from Employee balances
        LeaveBalance balanceMap = leaveBalanceRepository.findByEmployeeId(req.getEmployeeId()).orElse(null);
        if (balanceMap != null && !req.getLeaveType().equalsIgnoreCase("UNPAID")) {
            deductCategoryBalance(balanceMap, req.getLeaveType(), (int) gapDays);
            leaveBalanceRepository.save(balanceMap);
        }

        req.setStatus("APPROVED");
        req.setApprovedBy(approver);
        req.setRemarks(remarks != null ? remarks : "Approved as per internal guidelines.");

        leaveRequestRepository.save(req);
        return ResponseEntity.ok(req);
    }

    @PutMapping("/reject/{id}")
    public ResponseEntity<?> rejectLeave(@PathVariable String id, @RequestParam String approver, @RequestParam(required = false) String remarks) {
        LeaveRequest req = leaveRequestRepository.findById(id).orElse(null);
        if (req == null) {
            return ResponseEntity.notFound().build();
        }

        req.setStatus("REJECTED");
        req.setApprovedBy(approver);
        req.setRemarks(remarks != null ? remarks : "Rejected: Operational coverage requirements.");

        leaveRequestRepository.save(req);
        return ResponseEntity.ok(req);
    }

    private int getCategoryBalance(LeaveBalance bal, String category) {
        return switch (category.toUpperCase()) {
            case "ANNUAL" -> bal.getAnnual();
            case "SICK" -> bal.getSick();
            case "CASUAL" -> bal.getCasual();
            case "MATERNITY" -> bal.getMaternity();
            default -> 0;
        };
    }

    private void deductCategoryBalance(LeaveBalance bal, String category, int days) {
        switch (category.toUpperCase()) {
            case "ANNUAL" -> bal.setAnnual(Math.max(bal.getAnnual() - days, 0));
            case "SICK" -> bal.setSick(Math.max(bal.getSick() - days, 0));
            case "CASUAL" -> bal.setCasual(Math.max(bal.getCasual() - days, 0));
            case "MATERNITY" -> bal.setMaternity(Math.max(bal.getMaternity() - days, 0));
        }
    }
}
