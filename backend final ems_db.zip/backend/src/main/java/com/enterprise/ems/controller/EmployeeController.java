/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

package com.enterprise.ems.controller;

import com.enterprise.ems.entity.Employee;
import com.enterprise.ems.entity.LeaveBalance;
import com.enterprise.ems.repository.EmployeeRepository;
import com.enterprise.ems.repository.LeaveBalanceRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import java.util.UUID;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/v1/employees")
public class EmployeeController {

    private final EmployeeRepository employeeRepository;
    private final LeaveBalanceRepository leaveBalanceRepository;

    public EmployeeController(EmployeeRepository employeeRepository, LeaveBalanceRepository leaveBalanceRepository) {
        this.employeeRepository = employeeRepository;
        this.leaveBalanceRepository = leaveBalanceRepository;
    }

    @GetMapping
    public ResponseEntity<Page<Employee>> getEmployees(
            @RequestParam(required = false) String query,
            @RequestParam(required = false) String departmentId,
            @RequestParam(required = false) String status,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "employeeCode") String sortBy,
            @RequestParam(defaultValue = "asc") String direction
    ) {
        Sort sort = direction.equalsIgnoreCase("desc") 
                ? Sort.by(sortBy).descending() 
                : Sort.by(sortBy).ascending();
                
        Pageable pageable = PageRequest.of(page, size, sort);
        Page<Employee> results = employeeRepository.searchEmployees(query, departmentId, status, pageable);
        return ResponseEntity.ok(results);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Employee> getEmployeeById(@PathVariable String id) {
        return employeeRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<?> createEmployee(@Valid @RequestBody Employee employee) {
        if (employeeRepository.existsByEmail(employee.getEmail())) {
            return ResponseEntity.badRequest().body("Error: Email is already mapped to an active employee profile!");
        }

        // Establish IDs
        employee.setId("emp-" + UUID.randomUUID().toString().substring(0, 8));
        String rawCodeNum = String.valueOf(100 + employeeRepository.count() + 1);
        employee.setEmployeeCode("EMP-00" + rawCodeNum);
        
        Employee saved = employeeRepository.save(employee);

        // Generate standard leave balance row
        LeaveBalance initBalance = LeaveBalance.builder()
                .id("bal-" + saved.getId())
                .employeeId(saved.getId())
                .annual(25)
                .sick(15)
                .casual(10)
                .maternity(saved.getGender() != null && saved.getGender().equalsIgnoreCase("Female") ? 90 : 0)
                .unpaid(10)
                .build();
        leaveBalanceRepository.save(initBalance);

        return ResponseEntity.ok(saved);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateEmployee(@PathVariable String id, @Valid @RequestBody Employee currentDetails) {
        return employeeRepository.findById(id)
                .map(existing -> {
                    existing.setFirstName(currentDetails.getFirstName());
                    existing.setLastName(currentDetails.getLastName());
                    existing.setEmail(currentDetails.getEmail());
                    existing.setPhone(currentDetails.getPhone());
                    existing.setDesignation(currentDetails.getDesignation());
                    existing.setDepartmentId(currentDetails.getDepartmentId());
                    existing.setSalary(currentDetails.getSalary());
                    existing.setStatus(currentDetails.getStatus());
                    existing.setAddress(currentDetails.getAddress());
                    existing.setDob(currentDetails.getDob());
                    existing.setGender(currentDetails.getGender());
                    if (currentDetails.getPhotoUrl() != null) {
                        existing.setPhotoUrl(currentDetails.getPhotoUrl());
                    }
                    Employee saved = employeeRepository.save(existing);
                    return ResponseEntity.ok(saved);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteEmployee(@PathVariable String id) {
        if (!employeeRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        employeeRepository.deleteById(id);
        return ResponseEntity.ok("Employee profile deleted successfully.");
    }
}
