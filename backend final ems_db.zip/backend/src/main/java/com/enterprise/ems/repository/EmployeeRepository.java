/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

package com.enterprise.ems.repository;

import com.enterprise.ems.entity.Employee;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, String> {
    
    @Query("SELECT e FROM Employee e WHERE " +
           "(:query IS NULL OR LOWER(e.firstName) LIKE LOWER(CONCAT('%', :query, '%')) " +
           "OR LOWER(e.lastName) LIKE LOWER(CONCAT('%', :query, '%')) " +
           "OR LOWER(e.employeeCode) LIKE LOWER(CONCAT('%', :query, '%')) " +
           "OR LOWER(e.designation) LIKE LOWER(CONCAT('%', :query, '%'))) " +
           "AND (:departmentId IS NULL OR e.departmentId = :departmentId) " +
           "AND (:status IS NULL OR e.status = :status)")
    Page<Employee> searchEmployees(
            @Param("query") String query,
            @Param("departmentId") String departmentId,
            @Param("status") String status,
            Pageable pageable
    );

    boolean existsByEmail(String email);
    boolean existsByEmployeeCode(String employeeCode);
}
