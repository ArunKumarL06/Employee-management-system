/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

package com.enterprise.ems.controller;

import com.enterprise.ems.entity.Payroll;
import com.enterprise.ems.entity.Employee;
import com.enterprise.ems.repository.PayrollRepository;
import com.enterprise.ems.repository.EmployeeRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/v1/payroll")
public class PayrollController {

    private final PayrollRepository payrollRepository;
    private final EmployeeRepository employeeRepository;

    public PayrollController(PayrollRepository payrollRepository, EmployeeRepository employeeRepository) {
        this.payrollRepository = payrollRepository;
        this.employeeRepository = employeeRepository;
    }

    @GetMapping
    public ResponseEntity<List<Payroll>> getPayrolls(@RequestParam(required = false) String period) {
        if (period != null) {
            return ResponseEntity.ok(payrollRepository.findAllByPayPeriod(period));
        }
        return ResponseEntity.ok(payrollRepository.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Payroll> getPayrollById(@PathVariable String id) {
        return payrollRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/generate-batch")
    public ResponseEntity<?> generateMonthlyPayrollBatch(@RequestParam String period) {
        List<Employee> activeStaff = employeeRepository.findAll().stream()
                .filter(e -> !e.getStatus().equalsIgnoreCase("INACTIVE"))
                .toList();
                
        if (activeStaff.isEmpty()) {
            return ResponseEntity.badRequest().body("Error: No active employees found to generate payroll.");
        }

        List<Payroll> generatedBatch = new ArrayList<>();

        for (Employee emp : activeStaff) {
            if (payrollRepository.existsByPayPeriodAndEmployeeId(period, emp.getId())) {
                continue; // Skip already compiled entries
            }

            BigDecimal base = emp.getSalary();
            BigDecimal allowances = base.multiply(BigDecimal.valueOf(0.12)).setScale(2, RoundingMode.HALF_UP);
            BigDecimal deductions = base.multiply(BigDecimal.valueOf(0.05)).setScale(2, RoundingMode.HALF_UP);
            
            // Tax bracket tiers
            double taxRate = base.doubleValue() > 7500 ? 0.20 : base.doubleValue() > 5000 ? 0.15 : 0.10;
            BigDecimal compTotal = base.add(allowances).subtract(deductions);
            BigDecimal taxAmount = compTotal.multiply(BigDecimal.valueOf(taxRate)).setScale(2, RoundingMode.HALF_UP);

            BigDecimal net = compTotal.subtract(taxAmount).setScale(2, RoundingMode.HALF_UP);

            String rawPeriodNoDash = period.replace("-", "");

            Payroll row = Payroll.builder()
                    .id("pay-" + period + "-" + emp.getId())
                    .payrollCode("PAY-" + rawPeriodNoDash + "-" + emp.getId().toUpperCase().substring(0, 4))
                    .employeeId(emp.getId())
                    .payPeriod(period)
                    .basicSalary(base)
                    .allowances(allowances)
                    .deductions(deductions)
                    .taxAmount(taxAmount)
                    .netSalary(net)
                    .status("PENDING")
                    .processedDate(LocalDate.now())
                    .build();

            generatedBatch.add(row);
        }

        if (generatedBatch.isEmpty()) {
            return ResponseEntity.badRequest().body("Error: Payroll for " + period + " is already compiled for all employees!");
        }

        payrollRepository.saveAll(generatedBatch);
        return ResponseEntity.ok("Successfully processed monthly payroll. Produced " + generatedBatch.size() + " payslip sheets.");
    }

    @PostMapping("/distribute")
    public ResponseEntity<?> distributeSalaries(@RequestParam String period) {
        List<Payroll> pendingList = payrollRepository.findAllByPayPeriod(period).stream()
                .filter(p -> p.getStatus().equalsIgnoreCase("PENDING"))
                .toList();
        if (pendingList.isEmpty()) {
            return ResponseEntity.badRequest().body("Error: No pending payroll items found for " + period);
        }
        for (Payroll p : pendingList) {
            p.setStatus("PAID");
        }
        payrollRepository.saveAll(pendingList);
        return ResponseEntity.ok("Cleared corporate funds! Successfully disbursed salaries for period " + period);
    }
}
