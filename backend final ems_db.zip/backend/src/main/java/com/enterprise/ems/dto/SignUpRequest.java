/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

package com.enterprise.ems.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class SignUpRequest {
    @NotBlank(message = "Username key is required")
    @Size(min = 3, max = 50, message = "Username length should balance between 3 and 50 characters")
    private String username;

    @NotBlank(message = "Email address is required")
    @Email(message = "Invalid corporate email pattern")
    private String email;

    @NotBlank(message = "Password constraint is required")
    @Size(min = 6, max = 100, message = "Password must span at least 6 characters")
    private String password;

    @NotBlank(message = "Role specification is required")
    private String role; // 'ADMIN', 'EMPLOYEE'

    private String employeeId;
}
