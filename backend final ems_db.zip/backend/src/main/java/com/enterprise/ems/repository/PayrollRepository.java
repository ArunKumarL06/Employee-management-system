/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

package com.enterprise.ems.repository;

import com.enterprise.ems.entity.Payroll;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface PayrollRepository extends JpaRepository<Payroll, String> {
    List<Payroll> findAllByEmployeeId(String employeeId);
    List<Payroll> findAllByPayPeriod(String payPeriod);
    Optional<Payroll> findByEmployeeIdAndPayPeriod(String employeeId, String payPeriod);
    boolean existsByPayPeriodAndEmployeeId(String payPeriod, String employeeId);
}
