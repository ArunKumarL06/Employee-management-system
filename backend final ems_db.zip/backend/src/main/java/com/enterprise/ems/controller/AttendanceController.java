/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

package com.enterprise.ems.controller;

import com.enterprise.ems.entity.Attendance;
import com.enterprise.ems.repository.AttendanceRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.UUID;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/v1/attendance")
public class AttendanceController {

    private final AttendanceRepository attendanceRepository;

    public AttendanceController(AttendanceRepository attendanceRepository) {
        this.attendanceRepository = attendanceRepository;
    }

    @GetMapping
    public ResponseEntity<List<Attendance>> getAttendance(
            @RequestParam(required = false) String date,
            @RequestParam(required = false) String employeeId
    ) {
        if (employeeId != null) {
            return ResponseEntity.ok(attendanceRepository.findAllByEmployeeId(employeeId));
        }
        if (date != null) {
            return ResponseEntity.ok(attendanceRepository.findAllByDate(LocalDate.parse(date)));
        }
        return ResponseEntity.ok(attendanceRepository.findAll());
    }

    @PostMapping("/check-in/{employeeId}")
    public ResponseEntity<?> checkIn(@PathVariable String employeeId) {
        LocalDate today = LocalDate.now();
        if (attendanceRepository.findByEmployeeIdAndDate(employeeId, today).isPresent()) {
            return ResponseEntity.badRequest().body("Error: Employee is already checked in for today!");
        }

        Attendance log = Attendance.builder()
                .id("att-" + UUID.randomUUID().toString().substring(0, 8))
                .employeeId(employeeId)
                .date(today)
                .checkIn(LocalTime.now())
                .status("PRESENT")
                .build();

        Attendance saved = attendanceRepository.save(log);
        return ResponseEntity.ok(saved);
    }

    @PostMapping("/check-out/{employeeId}")
    public ResponseEntity<?> checkOut(@PathVariable String employeeId) {
        LocalDate today = LocalDate.now();
        Attendance log = attendanceRepository.findByEmployeeIdAndDate(employeeId, today)
                .orElse(null);

        if (log == null) {
            return ResponseEntity.badRequest().body("Error: No check-in record found for today's shift!");
        }

        if (log.getCheckOut() != null) {
            return ResponseEntity.badRequest().body("Error: Employee has already checked out for today!");
        }

        LocalTime outTime = LocalTime.now();
        log.setCheckOut(outTime);

        // Compute decimal hours
        Duration gap = Duration.between(log.getCheckIn(), outTime);
        double hrs = Math.round((gap.toMinutes() / 60.0) * 10.0) / 10.0;
        log.setHoursWorked(BigDecimal.valueOf(hrs));

        Attendance saved = attendanceRepository.save(log);
        return ResponseEntity.ok(saved);
    }

    @PostMapping
    public ResponseEntity<?> createManualAttendance(@RequestBody Attendance attendance) {
        if (attendance.getId() == null) {
            attendance.setId("att-" + java.util.UUID.randomUUID().toString().substring(0, 8));
        }
        Attendance saved = attendanceRepository.save(attendance);
        return ResponseEntity.ok(saved);
    }
}
