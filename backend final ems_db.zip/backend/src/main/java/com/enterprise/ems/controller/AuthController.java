/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

package com.enterprise.ems.controller;

import com.enterprise.ems.dto.*;
import com.enterprise.ems.entity.User;
import com.enterprise.ems.repository.UserRepository;
import com.enterprise.ems.security.JwtUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import java.util.UUID;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/v1/auth")
@Validated
public class AuthController {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtils jwtUtils;

    public AuthController(UserRepository userRepository, PasswordEncoder passwordEncoder, JwtUtils jwtUtils) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtUtils = jwtUtils;
    }

    @PostMapping("/login")
    public ResponseEntity<?> authenticateUser(@Valid @RequestBody LoginRequest loginRequest) {
        User user = userRepository.findByUsername(loginRequest.getUsername())
                .orElse(null);

        if (user == null || !passwordEncoder.matches(loginRequest.getPassword(), user.getPasswordHash())) {
            return ResponseEntity.badRequest().body("Error: Invalid credentials resolved inside security logs!");
        }

        String jwt = jwtUtils.generateTokenFromUsername(user.getUsername(), user.getRole());

        return ResponseEntity.ok(new JwtResponse(
                jwt,
                user.getUsername(),
                user.getRole(),
                user.getEmployeeId()
        ));
    }

    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@Valid @RequestBody SignUpRequest signUpRequest) {
        if (userRepository.existsByUsername(signUpRequest.getUsername())) {
            return ResponseEntity.badRequest().body("Error: Username is already registered inside enterprise directory!");
        }

        if (userRepository.existsByEmail(signUpRequest.getEmail())) {
            return ResponseEntity.badRequest().body("Error: Corporate Email address is already connected!");
        }

        // Establish secure User node
        User freshUser = User.builder()
                .id("usr-" + UUID.randomUUID().toString().substring(0, 8))
                .username(signUpRequest.getUsername())
                .email(signUpRequest.getEmail())
                .passwordHash(passwordEncoder.encode(signUpRequest.getPassword()))
                .role(signUpRequest.getRole().toUpperCase())
                .employeeId(signUpRequest.getEmployeeId())
                .build();

        userRepository.save(freshUser);

        return ResponseEntity.ok("User registered successfully. Standard keys generated, password Bcrypt-hashed!");
    }

    @PutMapping("/user/{username}/link-employee")
    public ResponseEntity<?> linkEmployeeToUser(@PathVariable String username, @RequestParam String employeeId) {
        User user = userRepository.findByUsername(username).orElse(null);
        if (user == null) {
            return ResponseEntity.badRequest().body("Error: User not found!");
        }
        user.setEmployeeId(employeeId);
        userRepository.save(user);
        return ResponseEntity.ok("Successfully linked employee ID to user.");
    }
}
