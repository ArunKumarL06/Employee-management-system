-- Employee Management System - Corporate Schema Script DDL
-- Supported by MySQL Server

CREATE DATABASE IF NOT EXISTS ems_db;
USE ems_db;

-- 1. Departments table
CREATE TABLE IF NOT EXISTS departments (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    code VARCHAR(15) NOT NULL UNIQUE,
    description TEXT,
    manager_id VARCHAR(50)
);

-- 2. Employees table
CREATE TABLE IF NOT EXISTS employees (
    id VARCHAR(50) PRIMARY KEY,
    employee_code VARCHAR(30) UNIQUE NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(30),
    designation VARCHAR(100) NOT NULL,
    department_id VARCHAR(50),
    hire_date DATE NOT NULL,
    salary DECIMAL(12,2) NOT NULL,
    status VARCHAR(30) NOT NULL, -- 'ACTIVE', 'INACTIVE', 'ON_LEAVE'
    photo_url TEXT,
    address TEXT,
    dob DATE,
    gender VARCHAR(30),
    FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL
);

-- Circular Head Reference assignment
-- ALTER TABLE departments ADD FOREIGN KEY (manager_id) REFERENCES employees(id) ON DELETE SET NULL;

-- 3. Users table
CREATE TABLE IF NOT EXISTS users (
    id VARCHAR(50) PRIMARY KEY,
    username VARCHAR(100) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(30) NOT NULL, -- 'ADMIN', 'EMPLOYEE'
    employee_id VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
);

-- 4. Attendance table
CREATE TABLE IF NOT EXISTS attendance (
    id VARCHAR(50) PRIMARY KEY,
    employee_id VARCHAR(50) NOT NULL,
    date DATE NOT NULL,
    check_in TIME NOT NULL,
    check_out TIME,
    status VARCHAR(30) NOT NULL, -- 'PRESENT', 'ABSENT', 'LATE', 'HALF_DAY'
    hours_worked DECIMAL(4,1),
    UNIQUE KEY emp_date_unique (employee_id, date),
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
);

-- 5. Leave Requests table
CREATE TABLE IF NOT EXISTS leave_requests (
    id VARCHAR(50) PRIMARY KEY,
    employee_id VARCHAR(50) NOT NULL,
    leave_type VARCHAR(30) NOT NULL, -- 'ANNUAL', 'SICK', 'CASUAL', 'MATERNITY', 'UNPAID'
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    reason TEXT NOT NULL,
    status VARCHAR(30) NOT NULL, -- 'PENDING', 'APPROVED', 'REJECTED'
    applied_date DATE NOT NULL,
    approved_by VARCHAR(100),
    remarks TEXT,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
);

-- 6. Leave Balances table
CREATE TABLE IF NOT EXISTS leave_balances (
    id VARCHAR(50) PRIMARY KEY,
    employee_id VARCHAR(50) NOT NULL UNIQUE,
    annual INT DEFAULT 25,
    sick INT DEFAULT 15,
    casual INT DEFAULT 10,
    maternity INT DEFAULT 90,
    unpaid INT DEFAULT 10,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
);

-- 7. Payroll table
CREATE TABLE IF NOT EXISTS payroll (
    id VARCHAR(50) PRIMARY KEY,
    payroll_code VARCHAR(50) UNIQUE NOT NULL,
    employee_id VARCHAR(50) NOT NULL,
    pay_period VARCHAR(15) NOT NULL, -- 'YYYY-MM'
    basic_salary DECIMAL(12,2) NOT NULL,
    allowances DECIMAL(12,2) DEFAULT 0.0,
    deductions DECIMAL(12,2) DEFAULT 0.0,
    tax_amount DECIMAL(12,2) DEFAULT 0.0,
    net_salary DECIMAL(12,2) NOT NULL,
    status VARCHAR(30) NOT NULL, -- 'PAID', 'PENDING'
    processed_date DATE NOT NULL,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
);

-- 8. Corporate Documents table
CREATE TABLE IF NOT EXISTS documents (
    id VARCHAR(50) PRIMARY KEY,
    employee_id VARCHAR(50) NOT NULL,
    title VARCHAR(150) NOT NULL,
    type VARCHAR(50) NOT NULL, -- 'CONTRACT', 'ID_PROOFS', 'TAX_W2', 'CV'
    file_path TEXT NOT NULL,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
);


-- PRE-SEED DATA FOR DIRECT DATABASE INITIALIZATION

-- Insert departments
INSERT INTO departments (id, name, code, description) VALUES 
('dept-1', 'Software Engineering', 'ENG', 'Web, Mobile, and Cloud Application Development and DevOps'),
('dept-2', 'Human Resources', 'HR', 'Talent Acquisition, Employee Relations, and Wellness'),
('dept-3', 'Financial Operations', 'FIN', 'Management of Payroll, Taxes, Financial Reporting, and Budgets'),
('dept-4', 'Marketing & Sales', 'MKT', 'Digital Marketing, Brand Management, and Client Relations');

-- Insert employees
INSERT INTO employees (id, employee_code, first_name, last_name, email, phone, designation, department_id, hire_date, salary, status, address, dob, gender) VALUES 
('emp-101', 'EMP-00101', 'Sarah', 'Connor', 'sconnor@enterprise.com', '+1 (555) 234-5678', 'Engineering Manager', 'dept-1', '2023-03-15', 8200.00, 'ACTIVE', '123 Cyber Way, Los Angeles, CA', '1987-11-10', 'Female'),
('emp-102', 'EMP-00102', 'Marcus', 'Vance', 'mvance@enterprise.com', '+1 (555) 345-6789', 'Senior Backend Architect', 'dept-1', '2024-01-10', 6800.00, 'ACTIVE', '456 Tech Boulevard, San Francisco, CA', '1990-05-14', 'Male'),
('emp-103', 'EMP-00103', 'Elena', 'Rostova', 'erostova@enterprise.com', '+1 (555) 456-7890', 'HR Director', 'dept-2', '2022-08-01', 6200.00, 'ACTIVE', '789 Harmony Circle, San Diego, CA', '1984-03-22', 'Female');

-- Update department heads
UPDATE departments SET manager_id = 'emp-103' WHERE id = 'dept-2';
UPDATE departments SET manager_id = 'emp-101' WHERE id = 'dept-1';

-- Insert users (Hash value matches standard security: admin123 and user123)
-- BCrypt hashees pre-compiled for convenience
INSERT INTO users (id, username, email, password_hash, role, employee_id) VALUES 
('user-admin', 'admin', 'admin@enterprise.com', '$2a$10$tM2PjP0X6uB771e7Cq/9Iug3Vv.IeDk96DaeH2L8zefx0v7YcO9eC', 'ADMIN', NULL),
('user-sconnor', 'sconnor', 'sconnor@enterprise.com', '$2a$10$O3mpxf.Yv3Xb283K7rGjueM7.S90NlEeh30vR1X9a3R6Oa3eC99eS', 'EMPLOYEE', 'emp-101');

-- Insert Leave Balances
INSERT INTO leave_balances (id, employee_id, annual, sick, casual, maternity, unpaid) VALUES 
('bal-emp-101', 'emp-101', 25, 15, 10, 0, 10),
('bal-emp-102', 'emp-102', 25, 15, 10, 0, 10),
('bal-emp-103', 'emp-103', 25, 15, 10, 90, 10);
